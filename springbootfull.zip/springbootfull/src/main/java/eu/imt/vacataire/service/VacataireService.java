package eu.imt.vacataire.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import eu.imt.vacataire.controller.dto.VacataireDto;
import eu.imt.vacataire.repository.VacataireRepository;
import eu.imt.vacataire.repository.entity.Vacataire;
import eu.imt.vacataire.service.mapper.VacataireMapper;

@Service
public class VacataireService {

	@Autowired
	private VacataireRepository vacataireRepository;
	

	public List<VacataireDto> getVacataires() {
		List<Vacataire> liste = vacataireRepository.findAll();
		List<VacataireDto> listeDto = new ArrayList<>();
		for (Vacataire v : liste) {
			listeDto.add(VacataireMapper.toDto(v));
		}
		
		return listeDto;
	}
	
	public void ajouterVacataire(VacataireDto dto) {
		Vacataire v = VacataireMapper.toEntity(dto);
		vacataireRepository.save(v);
	}
}
