package eu.imt.vacataire.controller.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class VacataireDto {

	private long id;
	
	@NotBlank(message = "Le nom est obligatoire")
	private String nom;
	private String prenom;
	
	@Pattern(regexp = "^[0-9]{5}$", message="Code postal sous la forme xxxxx")
	private String codePostal;
	
	@NotBlank
	@Size(min = 3, max = 10)
	private String ville;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getCodePostal() {
		return codePostal;
	}
	public void setCodePostal(String codePostal) {
		this.codePostal = codePostal;
	}
	public String getVille() {
		return ville;
	}
	public void setVille(String ville) {
		this.ville = ville;
	}
	
	
	
	
}
