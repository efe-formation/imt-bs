package eu.imt.vacataire.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import eu.imt.vacataire.repository.entity.Vacataire;

public interface VacataireRepository extends JpaRepository<Vacataire, Long> {

}
