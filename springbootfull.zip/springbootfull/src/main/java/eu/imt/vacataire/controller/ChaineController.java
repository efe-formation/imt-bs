package eu.imt.vacataire.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ChaineController {
	
	public ChaineController() {
		System.out.println("Construction d'un VacataireController");
	
	}
	
	@GetMapping("/chaine")
	public String chaine(Model model) {
		System.out.println("Appel de la methode chaine");
		model.addAttribute("chaineaafficher", "Bienvenue dans le monde de Spring");
		
		return "affichechaine";
	}

}
