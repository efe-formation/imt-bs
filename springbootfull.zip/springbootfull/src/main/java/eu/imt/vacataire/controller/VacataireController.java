package eu.imt.vacataire.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import eu.imt.vacataire.controller.dto.VacataireDto;
import eu.imt.vacataire.repository.entity.Vacataire;
import eu.imt.vacataire.service.VacataireService;
import jakarta.validation.Valid;


@Controller
@RequestMapping("/vacataires")
public class VacataireController {

	@Autowired
	private VacataireService vacataireService;

	@GetMapping
	public String affichage(Model model) {
		
		List<VacataireDto> listeV = vacataireService.getVacataires();
		model.addAttribute("listeVacataires", listeV);
		VacataireDto nouveau = new VacataireDto();
		nouveau.setNom("Legrand");
		model.addAttribute("nouveau", nouveau);
		return "vacataires";
	}
	
	@PostMapping("/ajouter")
	public String ajouterVacataire(@ModelAttribute("nouveau") @Valid VacataireDto vacataire, BindingResult br, Model model) {
		
		if (br.hasErrors()) {
			System.out.println(br.getAllErrors());
			List<VacataireDto> listeV = vacataireService.getVacataires();
			model.addAttribute("listeVacataires", listeV);
			return "vacataires";
		}
		else
			vacataireService.ajouterVacataire(vacataire);
		return "redirect:/vacataires";
	}
	

}
