package eu.imt.vacataire.service.mapper;

import eu.imt.vacataire.controller.dto.VacataireDto;
import eu.imt.vacataire.repository.entity.Vacataire;

public class VacataireMapper {

	
	public static Vacataire toEntity(VacataireDto dto) {
		if (dto == null)
			return null;
		Vacataire v = new Vacataire();
		v.setId(dto.getId());
		v.setNom(dto.getNom());
		v.setPrenom(dto.getPrenom());
		v.getAdresse().setCodePostal(dto.getCodePostal());
		v.getAdresse().setVille(dto.getVille());
		
		return v;
	}
	
	public static VacataireDto toDto(Vacataire entity) {
		if (entity == null)
			return null;
		
		VacataireDto dto = new VacataireDto();
		dto.setId(entity.getId());
		dto.setNom(entity.getNom());
		dto.setPrenom(entity.getPrenom());
		dto.setCodePostal(entity.getAdresse().getCodePostal());
		dto.setVille(entity.getAdresse().getVille());
		return dto;
	}
}
