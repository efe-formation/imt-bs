package fr.formation.service.mapper;

import fr.formation.controller.dto.ContactDto;
import fr.formation.repository.entity.Contact;

public class ContactMapper {

	public static ContactDto toDTO(Contact contact) {
		if (contact == null)
			return null;
		
		ContactDto dto = new ContactDto();
        dto.setId(contact.getId());
        dto.setNom(contact.getNom());
        dto.setPrenom(contact.getPrenom());
        dto.setCodePostal(contact.getAdresse().getCodePostal());
        dto.setVille(contact.getAdresse().getVille());
        
        return dto;
    }

    public static Contact toEntity(ContactDto dto) {
    	if (dto == null)
			return null;
        Contact contact = new Contact();
        contact.setId(dto.getId());
        contact.setNom(dto.getNom());
        contact.setPrenom(dto.getPrenom());
        contact.getAdresse().setCodePostal(dto.getCodePostal());
        contact.getAdresse().setVille(dto.getVille());
        
        return contact;
    }
}
