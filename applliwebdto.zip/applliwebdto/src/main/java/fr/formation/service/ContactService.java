package fr.formation.service;

import java.util.List;

import fr.formation.controller.dto.ContactDto;

public interface ContactService {

	ContactDto addContact(ContactDto newContact);

	List<ContactDto> getContacts();

	ContactDto getContactById(long id);
	
	ContactDto updateContact(long id, ContactDto contact);
	
	boolean deleteContact(long id);

}