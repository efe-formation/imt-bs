package fr.formation.service;

import java.io.Serializable;
import java.util.List;

import fr.formation.controller.dto.ContactDto;
import fr.formation.repository.ContactRepository;
import fr.formation.repository.entity.Contact;
import fr.formation.service.mapper.ContactMapper;
import jakarta.ejb.Stateless;
import jakarta.inject.Inject;
import jakarta.inject.Named;

@Stateless
public class ContactStatelessService  implements Serializable, ContactService {

	private static final long serialVersionUID = 1L;
	
	@Inject
    private ContactRepository contactRepository;

    @Override
	public ContactDto addContact(ContactDto newContact) {
    	Contact contact = ContactMapper.toEntity(newContact);
    	contactRepository.createContact(contact);
    	
    	return ContactMapper.toDTO(contact);
    }

    @Override
	public List<ContactDto> getContacts() {
        List<Contact> contacts = contactRepository.getAllContacts();
        
		return contacts.stream().map(ContactMapper::toDTO).toList();
    }

	@Override
	public ContactDto getContactById(long id) {
		Contact contact = contactRepository.getContactById(id);
		return ContactMapper.toDTO(contact);
	}

	@Override
	public ContactDto updateContact(long id, ContactDto contact) {
		Contact contactEntity = ContactMapper.toEntity(contact);
		contactEntity = contactRepository.updateContact(id, contactEntity);
		return ContactMapper.toDTO(contactEntity);
	}

	@Override
	public boolean deleteContact(long id) {
		return contactRepository.deleteContact(id);
	}
}