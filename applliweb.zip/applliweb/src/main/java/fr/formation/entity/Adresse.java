package fr.formation.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Adresse {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    
    private String ville;
    private String codePostal;
    
    public Adresse() {
	}
    
	public Adresse(String ville, String codePostal) {
		this.ville = ville;
		this.codePostal = codePostal;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	public String getVille() {
		return ville;
	}
	public void setVille(String ville) {
		this.ville = ville;
	}
	public String getCodePostal() {
		return codePostal;
	}
	public void setCodePostal(String codePostal) {
		this.codePostal = codePostal;
	}
	@Override
	public String toString() {
		return "Adresse [id=" + id + ", ville=" + ville + ", codePostal=" + codePostal + "]";
	}
    
    

}
