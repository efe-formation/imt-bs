package fr.formation.controller;

import java.util.ArrayList;
import java.util.List;

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;

@Named
@RequestScoped
public class ContactListBean {

    private List<String> contacts;

    @PostConstruct
    public void init() {
        // Initialisez la liste des contacts (pour cet exemple, nous utilisons une liste statique)
        contacts = new ArrayList<>();
        contacts.add("John Doe");
        contacts.add("Jane Smith");
        contacts.add("Bob Johnson");
    }

    public List<String> getContacts() {
    	System.out.println(contacts);
        return contacts;
    }
}