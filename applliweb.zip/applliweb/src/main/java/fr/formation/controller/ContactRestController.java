package fr.formation.controller;

import java.io.Serializable;
import java.util.List;

import fr.formation.entity.Contact;
import fr.formation.service.ContactService;
import jakarta.ejb.Stateless;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/contacts")
@Stateless
public class ContactRestController implements Serializable {

   

	private static final long serialVersionUID = 1L;
	@Inject
	@Named("contactStatelessService")
    private ContactService contactService;

	@GET
    @Produces(MediaType.APPLICATION_JSON)
	public Response getContactsEnBase() {
		List<Contact> contacts = contactService.getContacts();
		return Response.ok(contacts).build();
	}
	

    @GET
    @Path("/json/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getContactByIdJson(@PathParam("id") Long id) {
        Contact contact = contactService.getContactById(id);
        if (contact == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        return Response.ok(contact).build();
    }
	

    @GET
    @Path("/xml/{id}")
    @Produces(MediaType.APPLICATION_XML)
    public Response getContactByIdXml(@PathParam("id") Long id) {
        Contact contact = contactService.getContactById(id);
        if (contact == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        return Response.ok(contact).build();
    }
	

    @GET
    @Path("/{id}")
    public Response getContactById(@PathParam("id") Long id) {
        Contact contact = contactService.getContactById(id);
        if (contact == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        return Response.ok(contact).build();
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addContact(Contact contact) {
        // Implémentez la logique pour ajouter un contact
        // Par exemple, contactService.addContact(contact);
        Contact addedContact = contactService.addContact(contact);

        return Response.status(Response.Status.CREATED)
                       .entity(addedContact)
                       .build();
    }
    
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateContact(@PathParam("id") Long id, Contact contact) {
        // Implémentez la logique pour mettre à jour un contact
        // Par exemple, vérifier si le contact existe, puis le mettre à jour
        Contact updatedContact = contactService.updateContact(id, contact);

        if (updatedContact == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }

        return Response.ok(updatedContact).build();
    }
    
    @DELETE
    @Path("/{id}")
    public Response deleteContact(@PathParam("id") Long id) {
        // Implémentez la logique pour supprimer un contact
        // Par exemple, vérifier si le contact existe, puis le supprimer
        boolean isDeleted = contactService.deleteContact(id);

        if (!isDeleted) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }

        return Response.noContent().build(); // HTTP 204 No Content
    }
}