package fr.formation.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import fr.formation.entity.Adresse;
import fr.formation.entity.Contact;
import fr.formation.service.ContactService;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.inject.Qualifier;

@Named
@SessionScoped
public class ContactController implements Serializable {

    private static final long serialVersionUID = 1L;

	@Inject
	@Named("contactSessionService")
    private ContactService contactService;

    private List<Contact> contacts;
    private Contact newContact;

    
    public ContactController() {
    	contacts = new ArrayList<>();
    	contacts.add(new Contact("Legrand", "Aline", new Adresse("Nantes", "44000")));
    	newContact = new Contact();
	}
    
    public String saveContact() {
    	 contacts.add(newContact);
    	 contactService.addContact(newContact);
         newContact = new Contact(); 
        return "listeContacts?faces-redirect=true";
    }

	public List<Contact> getContacts() {
		return contacts;
	}

	
	public List<Contact> getContactsEnBase() {
		return contactService.getContacts();
	}
	
	public void setContacts(List<Contact> contacts) {
		this.contacts = contacts;
	}

	public Contact getNewContact() {
		return newContact;
	}

	public void setNewContact(Contact newContact) {
		this.newContact = newContact;
	}

    
    
    
}