package fr.formation.service;

import java.io.Serializable;
import java.util.List;

import fr.formation.entity.Contact;
import fr.formation.repository.ContactRepository;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.inject.Qualifier;

@Named("contactSessionService")
@SessionScoped
public class ContactSessionService  implements Serializable, ContactService {

	private static final long serialVersionUID = 1L;
	
	@Inject
    private ContactRepository contactRepository;

    @Override
	public Contact addContact(Contact newContact) {
    	contactRepository.createContact(newContact);
    	return newContact;
    }

    @Override
	public List<Contact> getContacts() {
        return contactRepository.getAllContacts();
    }

	@Override
	public Contact getContactById(long id) {
		return contactRepository.getContactById(id);
	}

	@Override
	public Contact updateContact(long id, Contact contact) {
		return contactRepository.updateContact(id, contact);
	}

	@Override
	public boolean deleteContact(long id) {
		return contactRepository.deleteContact(id);
	}

	
}