package fr.formation.service;

import java.util.List;

import fr.formation.entity.Contact;

public interface ContactService {

	Contact addContact(Contact newContact);

	List<Contact> getContacts();

	Contact getContactById(long id);
	
	Contact updateContact(long id, Contact contact);
	
	boolean deleteContact(long id);

}