package fr.formation.repository;

import java.util.List;

import fr.formation.entity.Contact;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Stateless
public class ContactRepository {
	@PersistenceContext
	private EntityManager entityManager;

	public Contact createContact(Contact contact) {
		entityManager.persist(contact);
		return contact;
	}

	public Contact getContactById(long id) {
		return entityManager.find(Contact.class, id);
	}

	public List<Contact> getAllContacts() {
		return entityManager.createQuery("SELECT c FROM Contact c", Contact.class).getResultList();
	}



	public boolean deleteContact(long id) {
        Contact contactToDelete = entityManager.find(Contact.class, id);
        if (contactToDelete == null) {
            return false;
        }

        entityManager.remove(contactToDelete);
        return true;
    }

	public Contact updateContact(long id, Contact contact) {
        Contact contactToUpdate = entityManager.find(Contact.class, id);
        if (contactToUpdate == null) {
            // Le contact n'existe pas
            return null;
        }

        // Mettre à jour les champs du contact
        contactToUpdate.setNom(contact.getNom());
        contactToUpdate.setPrenom(contact.getPrenom());
        contactToUpdate.getAdresse().setCodePostal(contact.getAdresse().getCodePostal());
        contactToUpdate.getAdresse().setVille(contact.getAdresse().getVille());

        entityManager.merge(contactToUpdate);
        return contactToUpdate;
    }
}
