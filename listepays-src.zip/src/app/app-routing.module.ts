import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccueilComponent } from './accueil/accueil.component';
import { InfosPaysComponent } from './infos-pays/infos-pays.component';
import { ListePaysComponent } from './liste-pays/liste-pays.component';

const routes: Routes = [
  {path : "", component : AccueilComponent},
  {path : "listepays", component : ListePaysComponent},
  {path : "infospays", component : InfosPaysComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
