import { Component } from '@angular/core';
import { AppelpaysService } from '../appelpays.service';

@Component({
  selector: 'app-infos-pays',
  templateUrl: './infos-pays.component.html',
  styleUrls: ['./infos-pays.component.css']
})
export class InfosPaysComponent {
  alpha2Code : string = '';

  pays: any = {};
  erreur: string | null = null;
  constructor(private appelPays : AppelpaysService) { }

  traiterChangement() {
    if(this.alpha2Code.length == 2){
      this.appelPays.getPaysOne(this.alpha2Code)
      .subscribe({
        next : (data) => {
          this.pays = data;
          this.erreur = null;
        },
      error : (erreur) => {
        this.erreur = "Aucun pays ne correspond";
     }})}
     else{
      this.pays = {};
    }
   
  }

    paysOk() {
      return Object.keys(this.pays).length !== 0;
    }

 }
