import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InfosPaysComponent } from './infos-pays.component';

describe('InfosPaysComponent', () => {
  let component: InfosPaysComponent;
  let fixture: ComponentFixture<InfosPaysComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InfosPaysComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InfosPaysComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
