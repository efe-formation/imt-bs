import { TestBed } from '@angular/core/testing';

import { AppelpaysService } from './appelpays.service';

describe('AppelpaysService', () => {
  let service: AppelpaysService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AppelpaysService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
