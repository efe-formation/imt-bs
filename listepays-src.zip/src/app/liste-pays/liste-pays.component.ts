import { Component } from '@angular/core';
import { AppelpaysService } from '../appelpays.service';

@Component({
  selector: 'app-liste-pays',
  templateUrl: './liste-pays.component.html',
  styleUrls: ['./liste-pays.component.css']
})
export class ListePaysComponent {
  pays: any[] = [];
  constructor(private appelPays : AppelpaysService) { }

  ngOnInit(): void {
    this.loadContacts();
  }

  loadContacts(): void {
    this.appelPays.getPaysAll()
      .subscribe(data => {
        this.pays = data;
      });
  }
}
