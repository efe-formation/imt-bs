import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http"
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AppelpaysService {
  private apiUrlAll = 'https://restcountries.com/v2/all'; 
  private apiUrlOne = 'https://restcountries.com/v2/alpha/'; 

  constructor(private http: HttpClient) { }

  getPaysAll(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrlAll);
  }
  getPaysOne(alpha : string): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrlOne + alpha).pipe(
      catchError(this.gererErreur)
    );
  }

  private gererErreur(erreur: any) {
    return throwError(() => new Error(erreur.message || 'Erreur du serveur'));
  }
}
